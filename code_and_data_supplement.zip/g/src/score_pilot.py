"""从 results/ 的 pilot 分片 jsonl 算 ES/RR/CLR（plan §2.5，口径=生成式 ES_b，不等于 EasyEdit rewrite_acc）。

  python src/score_pilot.py --config experiments/pilot.yaml --editor ROME
  python src/score_pilot.py --config experiments/pilot.yaml --editor MEMIT

自动 glob 8 个分片合并后打分；cases 的 o_old/o_new 用清洗后全量查表（覆盖所有 case_id）。
"""
import argparse, json, glob, os, tempfile, yaml
from collections import Counter
import metrics


def _is_degenerate(s):
    """退化检测(**长度无关**):字符级复读(滑动 4-gram 不同占比极低)或词级复读(某词占比过高)。
    ⚠ 不能用 len(set(s))/len(s) —— 长的【正常】答案字符种类/长度天然低(600字英文≈0.07),会误杀
    70B 的 verbose 长答案(实测假阳 60-72%)。真垃圾('717717'/'Session Session')才是复读结构。"""
    s = (s or "").strip()
    if len(s) < 25:
        return False
    g = [s[i:i + 4] for i in range(len(s) - 3)]       # 滑动 4-gram:正常文本≈0.85,'717717'类≈0.1
    if g and len(set(g)) / len(g) < 0.40:
        return True
    w = s.split()                                     # 词级复读:'medical medical medical'/'Session Session of of'
    if len(w) >= 8 and Counter(w).most_common(1)[0][1] / len(w) > 0.25:
        return True
    return False


def collect(cfg, editor):
    ds = cfg["dataset"]
    pat = os.path.join(cfg["out_dir"], f"{cfg['model_tag']}_{editor}_{ds['tag']}_r*.jsonl")
    shards = sorted(glob.glob(pat))
    if not shards:
        raise SystemExit(f"没有结果文件：{pat}\n（先跑 src/run_pilot.py）")
    src = ds.get("fallback_path", ds["path"])           # o_old/o_new 查表源（全量覆盖）
    cases = [json.loads(l) for l in open(src)]
    aliases = json.load(open("data/aliases.json"))
    return shards, cases, aliases, src


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--editor", required=True)
    ap.add_argument("--boot", type=int, default=10000, help="bootstrap 次数(plan §2.5 n=10000)；0 跳过")
    ap.add_argument("--decode", default="greedy", help="解码臂 greedy/sample（采样臂须 sampling.enabled 跑过）")
    ap.add_argument("--cluster", action="store_true",
                    help="额外出【case 聚类】bootstrap CI（采样臂必用:同 case 多 seed 链非独立,"
                         "行级重采样=伪复制→CI 过窄;聚类按 case 整块重采样。见 an internal review 必2/硬伤1）")
    ap.add_argument("--drop-degenerate", action="store_true",
                    help="丢弃【答案退化(模型损坏)】的整条 case —— 抢救 model_parallel 70B 部分 case 被编辑累积搞坏的分片")
    args = ap.parse_args()
    cfg = yaml.safe_load(open(args.config))
    shards, cases, aliases, src = collect(cfg, args.editor)

    bad = set()
    if args.drop_degenerate:                 # 先扫一遍,标出答案退化的 case_id(整条丢)
        for s in shards:
            for l in open(s):
                try:
                    d = json.loads(l)
                except Exception:
                    continue
                if d.get("case_id") and _is_degenerate(d.get("answer", "")):
                    bad.add(d["case_id"])

    fd, merged = tempfile.mkstemp(suffix=".jsonl"); os.close(fd)
    n_err = n_drop = 0
    with open(merged, "w") as o:
        for s in shards:
            for l in open(s):
                if bad:                      # 跳过退化 case 的所有行
                    try:
                        cid = json.loads(l).get("case_id")
                    except Exception:
                        cid = None
                    if cid in bad:
                        continue
                if '"error"' in l:
                    n_err += 1
                o.write(l)
    if args.drop_degenerate:
        n_drop = len(bad)
        print(f"# [drop-degenerate] 丢弃退化 case {n_drop} 条(模型损坏);余下为干净子集")
    res = metrics.score(merged, cases, aliases, decode=args.decode)

    fmt = lambda x: f"{x:>8.3f}" if isinstance(x, float) else f"{'—':>8}"   # None → 占位（该档无该探针）
    print(f"# editor={args.editor}  shards={len(shards)}  错误行={n_err}  解码臂={args.decode}  o_old/o_new 源={src}")
    print(f"{'budget':<7}{'n':>5}{'ES':>8}{'ESf':>8}{'RR':>8}{'RRs':>8}{'CLR':>8}{'Flip':>8}{'PS':>8}{'Loc':>8}  (rr_n/n_para/n_loc)")
    for b in res:
        r = res[b]
        print(f"{b:<7}{r['n']:>5}{fmt(r['ES'])}{fmt(r['ESf'])}{fmt(r['RR'])}{fmt(r['RRs'])}{fmt(r['CLR'])}"
              f"{fmt(r['Flip'])}{fmt(r['PS'])}{fmt(r['Loc'])}  ({r['rr_n']}/{r['n_para']}/{r['n_loc']})")
    print("RR=答案含旧(上界,含'守住+顺带提旧')  RRs=答案含旧且不含新(下界,ES镜像,最干净回退)  真回退率在两者之间")
    print("Loc=locality answer 未直接泄漏 o_new；不检查邻域答案正确性，不能单独称完整 locality preservation")
    print("\nES=严格(命中 o_new 且不含 o_old)  ESf=首段断言(答案首立场=编辑)  Flip=答案内两立场都现(先新后旧)"
          "  —— ESf≫ES 且 Flip↑ = 答案内『越想越退』(07 教训, FlipPoint 见 analysis/09)")

    if args.boot:                                  # plan §2.5：95% bootstrap CI（按编辑条目重采样）
        bs = metrics.score_bootstrap(merged, cases, aliases, n_boot=args.boot, decode=args.decode)
        print(f"\n95% bootstrap CI (n={args.boot}, 按编辑条目重采样, plan §2.5)：")
        print(f"{'budget':<7}{'ES [lo, hi]':>24}{'RR [lo, hi]':>24}{'CLR [lo, hi]':>24}")
        cif = lambda t: f"{t[0]:.3f} [{t[1]:.3f},{t[2]:.3f}]" if t else "—"
        for b in bs:
            print(f"{b:<7}{cif(bs[b]['ES']):>24}{cif(bs[b]['RR']):>24}{cif(bs[b]['CLR']):>24}")

        if args.cluster:                           # an internal review 必2：case 聚类 CI（采样臂唯一正确口径）
            cbs = metrics.score_bootstrap_clustered(merged, cases, aliases, n_boot=args.boot, decode=args.decode)
            print(f"\n【case 聚类】95% bootstrap CI (n={args.boot}, 重采样单位=case,非 row)——采样臂多 seed 链非独立、行级 CI 伪复制过窄:")
            print(f"{'budget':<7}{'ES [lo, hi]':>24}{'RR [lo, hi]':>24}{'CLR [lo, hi]':>24}{'  n_case/n_row'}")
            cif4 = lambda t: f"{t[0]:.3f} [{t[1]:.3f},{t[2]:.3f}]" if t else "—"
            meta = lambda b: next((cbs[b][m][3] for m in ("ES","RR","CLR") if cbs[b].get(m)), {})
            for b in cbs:
                mt = meta(b)
                print(f"{b:<7}{cif4(cbs[b]['ES']):>24}{cif4(cbs[b]['RR']):>24}{cif4(cbs[b]['CLR']):>24}"
                      f"  {mt.get('n_cases','?')}/{mt.get('n_rows','?')}")
            print("  ↑点估与行级完全相同,只 CI 变宽;贪心臂(1 row/case)聚类=行级。写作/发布用【聚类】口径(呼应 draft §3.6 'resampling n facts')。")

        drop = metrics.drop_bootstrap(merged, cases, aliases, base="B0", n_boot=args.boot, decode=args.decode)
        print(f"\nES 降幅 ES(B0)−ES(b) 配对 bootstrap（plan §2.5；越想越退主判据，CI 全>0=显著回退）：")
        for b in sorted(drop):
            t = drop[b]
            sig = "  ✅CI>0 显著" if t and t[1] > 0 else ("  ⚠CI 含0" if t else "")
            print(f"  B0→{b}: {cif(t)}{sig}")

    os.remove(merged)
    print("\ngo/no-go (plan §Phase 1): RR(natural=B3)≥0.20 或 ES 自 B0 降幅≥0.20pp，"
          "且 ≥60% 回退案例可归因反思片段（人工审计 30 条）。")
    print("layer 选择纪律 (plan v1.18/§7): 在 Loc≥0.85 前提下取生成式 B0 ES 最高的层；"
          "旧 ES≥0.90 是 rewrite_acc 数字误植，不用于生成式结果作废。")


if __name__ == "__main__":
    main()
