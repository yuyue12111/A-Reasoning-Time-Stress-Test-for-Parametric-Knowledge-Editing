# Code and data supplement

Anonymous submission. This bundle supports assessment of the paper's claims; it
is not a general-purpose release.

## Layout

    src/                    experiment, scoring and analysis code
    src/vendor_patches/     our patches to the third-party editing library
    experiments/            run configs: which checkpoint, editor and budget made which cell
    data/                   alias table and benchmark licences
    prereg/                 the pre-specified protocols behind the reported gates
    paperwriting/results.json  every value the paper cites (see note below)
    PROVENANCE.md           what is and is not pre-result frozen evidence
    env.lock                pinned dependency versions

## Regenerating the tables and figures

    python src/plots.py --only all
    python src/generate_table_rq2.py

Both resolve `paperwriting/results.json` relative to the bundle root and write
back into `paperwriting/`, so they run here unmodified.

## Where each claim's code lives

| Paper section | What it claims | Code |
|---|---|---|
| S3 protocol | one edit at a time, scored at zero thinking and after a native chain, then reverted | `src/edit_loop.py`, `src/think_budget.py` |
| S3 scoring | generation-scored edit success and reversion, not teacher-forced logits | `src/metrics.py` |
| S3 gap | paired change per checkpoint, controls, sampling robustness | `src/percase_emergence.py`, `src/base_probe.py`, `src/f3_sampling_recalc.py` |
| S4 routes | in-chain route census and its adjudication | `src/chain_classify.py`, `src/p0_membership.py`, `src/p0_finalize_routes.py` |
| S4 replay gate | the vehicle that failed its own validity gate | `src/x1_replay.py`, `src/validate_x1_replay.py` |
| S5 intervention | signed think-span suppression, and the placebo/competitor arms | `src/suppress.py`, `src/steer.py`, `src/cross_arm.py`, `src/placebo_donor.py` |
| S5 transfer | second scale, second editor, paraphrase probes | `src/cross_arm_para.py`, `src/x3_para_readability.py` |
| S5 guard cost | accuracy on the unedited general sets | `src/genbench.py` |
| Tables/figures | regenerate from the distilled results | `src/plots.py`, `src/generate_table_rq2.py` |

## Two things to know before reading the code

**Comments are largely in the authors' working language, not English.** They are
engineering notes written during the runs, not documentation prepared for
release; they were left as written rather than rewritten after the fact, so the
record stays faithful. Several record failures and corrections candidly -- a
replay vehicle that did not pass its gate, a contaminated cell that was rebuilt,
a preregistered window that differed from the one the stored artifacts allowed
recomputing. Each of those is also disclosed in the paper or its technical
supplement; the notes corroborate those disclosures rather than adding new ones.

**`paperwriting/results.json` is derived, not raw.** It is emitted from the
working results file with internal annotation keys removed -- commentary,
superseded-analysis chains, run bookkeeping. The set of protected paths is
computed from the manuscript's own value bindings rather than hand-listed, so
every number the paper prints is present at the path the paper cites it from;
323 of 323 bindings resolve. It keeps the working file's name because the
analysis scripts resolve that path.

## What is deliberately absent

Manuscript tooling (the consistency checker, the caveat ledger, the abstract
audits) is not included: it encodes an internal review process and is not
evidence for any claim. Model weights, generated trajectories and judge outputs
are not included either -- they exceed the upload limit. The code that produces
them from a public checkpoint and the public CounterFact benchmark is here.
